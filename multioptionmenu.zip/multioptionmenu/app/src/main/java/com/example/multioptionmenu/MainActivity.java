package com.example.multioptionmenu;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvLongPress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ensure action bar is visible
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(R.string.title_options_menu);
            getSupportActionBar().show();
        }

        // Initialize TextView for Context Menu
        tvLongPress = findViewById(R.id.tvLongPress);

        // Register TextView for Context Menu
        registerForContextMenu(tvLongPress);
    }

    // Create Options Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu, menu);

        // Force show icons in overflow menu
        if (menu.getClass().getSimpleName().equals("MenuBuilder")) {
            try {
                java.lang.reflect.Method m = menu.getClass().getDeclaredMethod(
                        "setOptionalIconsVisible", Boolean.TYPE);
                m.setAccessible(true);
                m.invoke(menu, true);
            } catch (Exception e) {
                // Icons will not be shown in menu
            }
        }

        return true;
    }

    // Handle Options Menu item selection
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_add_contact) {
            Toast.makeText(this, R.string.toast_add_contact, Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.menu_settings) {
            Toast.makeText(this, R.string.toast_settings, Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.menu_about) {
            Toast.makeText(this, R.string.toast_about, Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // Create Context Menu
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.context_menu, menu);
        menu.setHeaderTitle(R.string.context_menu_header);
    }

    // Handle Context Menu item selection
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_copy) {
            Toast.makeText(this, R.string.toast_text_copied, Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.menu_delete) {
            tvLongPress.setVisibility(View.GONE);
            Toast.makeText(this, R.string.toast_text_deleted, Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onContextItemSelected(item);
    }
}